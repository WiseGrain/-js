function init(){
	var num=document.getElementById("num");
	num.value=0;
	num.disabled="disabled";

	/*
		为每个按钮定义内部自定义函数
	*/


	//注意：这里是一组元素，用Elements而不是Element!

	var oButton=document.getElementsByTagName("input");
	var btn_num1;
	var fh;
	for (var i=0;i<oButton.length;i++){
		oButton[i].onclick=function(){
			/*输入内容为数字*/
			if (isNumber(this.value)){
				//通过乘1的方式将"0123"变为123，从而消除前置的0
				num.value=(num.value+this.value)*1;

			}
			/*输入内容为非数字*/
			else{
				var btn_num=this.value;
				if (btn_num=="+"){
					btn_num1=Number(num.value);
					num.value=0;
					fh="+";
				}
				else if(btn_num=="-"){
					btn_num1=Number(num.value);
					num.value=0;
					fh="-";
				}
				else if(btn_num=="*"){
					btn_num1=Number(num.value);
					num.value=0;
					fh="*";
				}
				else if(btn_num=="/"){
					btn_num1=Number(num.value);
					num.value=0;
					fh="/";
				}
				else if(btn_num=="."){
					num.value=dec_number(num.value);
				}
				else if(btn_num=="+/-"){
					num.value=sign(num.value);
				}
				else if(btn_num=="c"){
					num.value="0";
				}
				else if(btn_num=="<-"){
					num.value=back(num.value);
				}
				else if(btn_num=="="){
					if(fh=="+"){
						num.value=btn_num1+Number(num.value);
					}
					else if(fh=="-"){
						num.value=btn_num1-Number(num.value);
					}
					else if(fh=="*"){
						num.value=btn_num1*Number(num.value);
					}
					else if(fh=="/"){
						if (num.value=="0"){
							alert("除数不能为0");
							num.value=0;
						}
						else{
							num.value=btn_num1/Number(num.value);
						}
						
					}
					
				}
				
			}
		}
	}
	

}

/*正负号*/
function sign(n){
	//遇到0
	if(n=="0"){
		return n;
	}
	//非0
	if (n.indexOf("-")==-1){
		n="-"+n;
	}
	else{
		n=n.substr(1,n.length);
	}

	return n;
}

/*小数点*/
function dec_number(n){
	if(n.indexOf(".")==-1){//indexOf()在字符串中寻找"."的位置，如果不存在，则返回-1
		n=n+".";
	}
	else{
		n=n;
	}
	return n;
}

/*判断文本框是否为空*/
function isNULL(n){
	if(n=="0" || n.length==0){
		return true;
	}
	else{
		return false;
	}
}

/*判断是否为数字*/
function isNumber(n){
	if (isNaN(n)==false){
		return true;
	}
	else{
		return false;
	}
}	
//isNaN:不能转化为数字是true,可以转化为数字是false

/*退位键*/
function back(n){
	if(!isNULL(n)){
		n=n.substr(0,n.length-1);
	}
	else{
		n="0";
	}

	if (n.length==0){
		n="0";
	}
	return n;
}