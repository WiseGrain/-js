function initm(){
	document.getElementById("imooc").onclick=function(){
		window.location.href="http://www.baidu.com";
	}
}